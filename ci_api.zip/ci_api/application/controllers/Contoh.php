<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';


class Contoh extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }

    //Menampilkan data Member
    function index_get() {
        $id = $this->get('userID');
        if ($id == '') {
            $member = $this->db->get('user')->result();
        } else {
            $this->db->where('userID', $id);
            $member = $this->db->get('user')->result();
        }
        $this->response($member, 200);
    }

 function index_post() {
        $data = array(
                    'userID'           => $this->post('userID'),
                    'Name'          => $this->post('Name'),
					'Email'          => $this->post('Email'),
					'Phone'          => $this->post ('Phone'),
					'Date'          => $this->post('Date'));
        $insert = $this->db->insert('user', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_put() {
        $id = $this->put('userID');
        $data = array(
                   
                    'Name'          => $this->put('Name'),
					'Email'          => $this->put('Email'),
					'Phone'          => $this->put('Phone'),
					'Date'          => $this->put('Date'));
        $this->db->where('userID', $id);
        $update = $this->db->update('user', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_delete() {
        $id = $this->delete('userID');
        $this->db->where('userID', $id);
        $delete = $this->db->delete('user');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
   
}
?>